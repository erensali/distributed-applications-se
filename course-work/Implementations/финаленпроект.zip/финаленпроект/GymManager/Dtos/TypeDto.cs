﻿namespace GymManager.Dtos
{
    public class TypeDto
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}