﻿toastr.options = {
    "debug": false,
    "closeButton": true,
    "progressBar": true
}