﻿namespace GymManager.Core
{
    public static class RoleName
    {
        public const string CanManageEmployees = "CanManageEmployees";
    }
}